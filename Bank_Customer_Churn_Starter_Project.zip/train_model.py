from pathlib import Path
import pandas as pd
import joblib
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, classification_report

ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / "European_Bank(1).csv"
if not DATA_PATH.exists():
    DATA_PATH = ROOT / "demo_bank_customers_SYNTHETIC.csv"
    print("WARNING: Original European_Bank(1).csv not found. Training on SYNTHETIC demo data.")
    print("Do not use these demo results as the results reported in your project report.")

df = pd.read_csv(DATA_PATH)
required = ["CreditScore","Geography","Gender","Age","Tenure","Balance","NumOfProducts",
            "HasCrCard","IsActiveMember","EstimatedSalary","Exited"]
missing = [c for c in required if c not in df.columns]
if missing:
    raise ValueError(f"Dataset is missing required columns: {missing}")

df["BalanceToSalaryRatio"] = df["Balance"] / df["EstimatedSalary"].replace(0, float("nan"))
df["ProductDensityIndicator"] = (df["NumOfProducts"] >= 2).astype(int)
df["EngagementProductInteraction"] = df["IsActiveMember"] * df["NumOfProducts"]
df["AgeTenureInteraction"] = df["Age"] * df["Tenure"]

features = ["CreditScore","Geography","Gender","Age","Tenure","Balance","NumOfProducts",
            "HasCrCard","IsActiveMember","EstimatedSalary","BalanceToSalaryRatio",
            "ProductDensityIndicator","EngagementProductInteraction","AgeTenureInteraction"]
X, y = df[features], df["Exited"].astype(int)
numeric = [c for c in features if c not in ["Geography","Gender"]]
categorical = ["Geography","Gender"]
preprocess = ColumnTransformer([
    ("num", Pipeline([("imputer", SimpleImputer(strategy="median"))]), numeric),
    ("cat", Pipeline([("imputer", SimpleImputer(strategy="most_frequent")),
                      ("onehot", OneHotEncoder(handle_unknown="ignore"))]), categorical)
])
model = Pipeline([("preprocess", preprocess),
                  ("classifier", RandomForestClassifier(n_estimators=300, min_samples_leaf=3,
                    class_weight="balanced_subsample", random_state=42))])
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)
model.fit(X_train, y_train)
pred = model.predict(X_test)
proba = model.predict_proba(X_test)[:, 1]
print(f"Dataset used: {DATA_PATH.name}")
print(f"Test accuracy: {accuracy_score(y_test,pred):.4f}")
print(f"Precision: {precision_score(y_test,pred,zero_division=0):.4f}")
print(f"Recall: {recall_score(y_test,pred,zero_division=0):.4f}")
print(f"F1: {f1_score(y_test,pred,zero_division=0):.4f}")
print(f"ROC-AUC: {roc_auc_score(y_test,proba):.4f}")
print(classification_report(y_test,pred,zero_division=0))
joblib.dump(model, ROOT / "churn_model.joblib")
joblib.dump(features, ROOT / "model_features.joblib")
print("Saved churn_model.joblib and model_features.joblib")
