# Bank Customer Churn Prediction

Academic prototype for estimating bank customer churn risk with a Random Forest classifier and Streamlit.

## Important data note
The supplied project report refers to `European_Bank(1).csv`, but that original dataset was not included when these starter files were prepared. `demo_bank_customers_SYNTHETIC.csv` is generated synthetic data for testing the application workflow only. **It is not the original dataset and must not be used to claim the metrics in the project report.**

To reproduce the report, place the permitted original dataset in this folder named `European_Bank(1).csv`, then run the training script again.

## Run locally
1. Install Python 3.10 or newer.
2. In a terminal in this folder, run:
   `pip install -r requirements.txt`
3. Train and save the model:
   `python train_model.py`
4. Launch the app:
   `streamlit run app.py`

## Files
- `app.py`: Streamlit interface for single-customer estimates and batch CSV scoring.
- `train_model.py`: preprocessing pipeline and Random Forest training script.
- `demo_bank_customers_SYNTHETIC.csv`: clearly labeled synthetic demo dataset.
- `requirements.txt`: required packages.

## Limitations
This is an educational demonstration, not a bank-approved decision system. Predictions are estimates, not guarantees. Before real use, validate data provenance, temporal validity, calibration, fairness, privacy, and performance on representative newer data. Do not upload confidential customer data to a public repository.
